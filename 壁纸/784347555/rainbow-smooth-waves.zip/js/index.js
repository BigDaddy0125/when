var w = c.width = window.innerWidth,
		h = c.height = window.innerHeight,
		ctx = c.getContext( '2d' ),
		
		opts = {
			
			columnWidth: 5,
			hueChange: 1,
			particleSpawnChance: .01,
			sinMultiplier: .1,
			cosMultiplier: .15,
			sinIncrementer: .3,
			cosIncrementer: .125,
			
			particleBaseSize: 2,
			particleAddedSize: 5,
			particleBrightnessIncrementer: 5
		},
		
		rects = [],
		particles = [],
		tick = 0;

function init(){
	
	rects.length = 0;
	for( var i = 0, n = tick; i < w + opts.columnWidth; i += opts.columnWidth, ++n )
		rects.push( getValue( n ) );
	
	if( tick === 0 )
		loop();
}
function loop() {
	
	window.requestAnimationFrame( loop );
	
	++tick;
	
	ctx.fillStyle = 'black';
	ctx.shadowBlur = 0;
	ctx.fillRect( 0, 0, w, h );
	
	rects.pop();
	rects.unshift( getValue( tick ) / 2 );
	
	for( var i = 0; i < rects.length; ++i ){
		
		var x = i * opts.columnWidth,
				hue = x / w * 360 + tick * opts.hueChange,
				value = rects[ i ],
				color = 'hsl( hue, 80%, light% )'.replace( 'hue', hue )
				
				gradient = ctx.createLinearGradient( x, 0, x, h );
		gradient.addColorStop( 0, color.replace( 'light', 90 ) );
		if( .25 + value > 0 )
			gradient.addColorStop( .25 + value, color.replace( 'light', 75 ) );
		gradient.addColorStop( .5 + value, color.replace( 'light', 50 ) );
		if( .75 + value < 1 )
			gradient.addColorStop( .75 + value, color.replace( 'light', 25 ) );
		gradient.addColorStop( 1, color.replace( 'light', 0 ) );
		
		ctx.fillStyle = gradient;
		ctx.fillRect( x, 0, opts.columnWidth, h );
		
		if( Math.random() < opts.particleSpawnChance ){
			
			var y = Math.random() * w,
					size = opts.particleBaseSize + opts.particleAddedSize * Math.random();
			
			particles.push( { x:x, y:y, size:size, color:color.replace( 'light', 100 - y / h * 50 ), life:10 } );
		}
	}
	
	for( var i = 0; i < particles.length; ++i ){
		
		var part = particles[ i ];
		
		ctx.fillStyle = part.color;
		ctx.fillRect( part.x, part.y - part.life, part.size, part.size );
		
		--part.life;
		
		if( part.life < 0 ){
			
			part.size -= .2;
			
			if( part.size < 0 ){
				
				particles.splice( i, 1 );
				--i;
			}
		}
	}
}

function getValue( x ){
	
	return Math.sin( x * opts.sinIncrementer ) * opts.sinMultiplier + Math.cos( x * opts.cosIncrementer ) * opts.cosMultiplier
}

init();

window.addEventListener( 'resize', function(){
	
	w = c.width = window.innerWidth;
	h = c.height = window.innerHeight;
	
	init();
})