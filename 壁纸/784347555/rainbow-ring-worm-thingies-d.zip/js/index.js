var w = c.width = window.innerWidth,
    h = c.height = window.innerHeight,
    ctx = c.getContext( '2d' ),
    
    lines = [],
    tick = 0,
    mode = 'stroke';

ctx.fillStyle = '#222';
ctx.fillRect( 0, 0, w, h );

function loop() {
  
  ++tick;
  
  window.requestAnimationFrame( loop );
  
  if( lines.length < 70 && Math.random() < .3 )
    lines.push( new Line );
  
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = 'rgba(0,0,0,.04)';
  ctx.fillRect( 0, 0, w, h );
  ctx.globalCompositeOperation = 'lighter';
  
  lines.map( function( line ) { line.step(); } );
  lines.map( function( line ) { line.draw(); } );
}

function Line() {
  
  this.reset();
}
Line.prototype.reset = function() {
  
  this.x1 = Math.random() * w;
  this.y1 = Math.random() * h;
  this.len = 10 + Math.random() * 20;
  this.rad = Math.random() * Math.PI * 2;
  this.angVel = .1 + Math.random() * .1;
  
  this.x2 = this.x1 + Math.cos( this.rad ) * this.len;
  this.y2 = this.y1 + Math.sin( this.rad ) * this.len;
  
  this.fixed = 1;
  this.time = 0;
}
Line.prototype.step = function() {
  
  ++this.time;
  
  if( this.fixed === 1 ) {
    
    this.rad += this.angVel;
    
    this.x2 = this.x1 + Math.cos( this.rad ) * this.len;
    this.y2 = this.y1 + Math.sin( this.rad ) * this.len;
    
    if( this.time > 20 || Math.random() < .01 ) {
      
      this.time = 0;
      
      this.rad -= Math.PI;
      this.fixed = 2;
      
      if( this.x2 < 0 || this.x2 > w || this.y2 < 0 || this.y2 > h )
        this.reset();
    }
    
  } else {
    
    this.rad -= this.angVel;
    
    this.x1 = this.x2 + Math.cos( this.rad ) * this.len;
    this.y1 = this.y2 + Math.sin( this.rad ) * this.len;
    
    if( this.time > 20 || Math.random() < .01 ) {
      
      this.time = 0;
      
      this.rad -= Math.PI;
      this.fixed = 1;
      
      if( this.x1 < 0 || this.x1 > w || this.y1 < 0 || this.y1 > h )
        this.reset();
    }
  }
}
Line.prototype.draw = function() {
  
  var x = this[ 'x' + this.fixed ],
      y = this[ 'y' + this.fixed ]
  
  if( mode === 'fill' ) {
    ctx.fillStyle = 'hsla(hue,80%,50%,.5)'.replace( 'hue', this.x1 / w * 360 + tick );
    ctx.beginPath();
    ctx.moveTo( x, y );
    ctx.arc( x, y, this.len, this.rad - this.angVel, this.rad + this.angVel );
    ctx.fill();
    
  } else {
    
    ctx.strokeStyle = 'hsla(hue,80%,50%,.5)'.replace( 'hue', this.x1 / w * 360 + tick );
    ctx.beginPath();
    ctx.arc( x, y, this.len, this.rad - this.angVel, this.rad + this.angVel );
    ctx.stroke();
  }
  
}
loop();

modeBtn.addEventListener( 'click', function() {
  
  mode = mode === 'fill' ? 'stroke' : 'fill';
  modeBtn.textContent = 'mode: ' + mode;
} )