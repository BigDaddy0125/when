
 // canvas setup //

var w = c.width = window.innerWidth,
    h = c.height = window.innerHeight,
    ctx = c.getContext( '2d' ),
    
  // parameters //
    
    particleCount = 250,
    yAttenuator = 50,
    xAttenuator = 30,
    hueAttenuator = 10,
    gravity = .1,
    explosionPower = 10,
    joinPointCount = 6,
    gatheringTime = 150,
    settlingTime = 250,
    clearAlpha = .04,
    particleAlpha = .2,
    bottomBounce = .6,
    sideBounce = .4,
    topBounce = false,
    jitter = 6,
  //reset = reset,
    
  // other values //
    
    particles,
    joinPoints,
    phase,
    time,
    colorTemplate,
    frameColorTemplate,
    jitter2,
    
  // gui stuff //
    
    gui,
    parameters = [ 'particleCount', 'yAttenuator', 'xAttenuator', 'hueAttenuator', 'gravity', 'explosionPower', 'joinPointCount', 'gatheringTime', 'settlingTime', 'clearAlpha', 'particleAlpha', 'bottomBounce', 'sideBounce' ],
    boundaries = [ [ 1, 400 ], [ 5, 100 ], [ 5, 100 ], [ 1, 200 ], [ .01, 2 ], [ 10, 50 ], [ 1, 50 ], [ 10, 1000 ], [ 10, 1000 ], [ 0, 1 ], [ 0, 1 ], [ .1, 1 ], [ .1, 1.5 ] ];

	// initializer function //

function init() {
  
  setGUIup();
  reset();
  
  for( var i = 0; i < 150; ++i ) doLogics( false );
  
  loop();
}

	// initializer sub functions //

function setGUIup() {
  
  gui = new dat.GUI;
  folder1 = gui.addFolder( 'parameters' );
  
  for( var i = 0; i < parameters.length; ++i) 
    folder1.add( window, parameters[i], boundaries[i][0], boundaries[i][1] );
  
  var folder2 = gui.addFolder( 'functions' );
  
  folder1.add( window, 'topBounce' );
  folder1.add( window, 'jitter' );
  folder2.add( window, 'enterGathering' );
  folder2.add( window, 'enterSettling' );
  folder2.add( window, 'reset' );
  
  folder2.open();
}

function reset() {
  
  ctx.lineWidth = 5;
  
  redraw();
  
  particles = [];
  joinPoints = [];
  phase = 'settling';
  time = 0,
  colorTemplate = 'hsla(hue, 80%, 50%, alp)';
  
  for( var i = 0; i < particleCount; ++i )
    particles.push( new Particle );
}

function redraw() {
  
  ctx.fillStyle = '#222';
  ctx.fillRect( 0, 0, w, h );
}

	// loop function & Co. //

function loop() {
  
  window.requestAnimationFrame( loop );
  
  doLogics( true );
}

function doLogics( render ){
  
  ++time;
  if( render ) repaint();
  
  frameColorTemplate = colorTemplate
    .replace( 'alp', particleAlpha );
  
  if( this.phase === 'settling')
    if( time >= settlingTime )
    	enterGathering();
  	else settle( render );
  
  else
    if( time >= gatheringTime )
      enterSettling();
  	else gather( render );
}

function repaint() {
  
  ctx.globalCompositeOperation = 'source-over';
  
  ctx.fillStyle = 'rgba(0, 0, 0, alp)'
  	.replace( 'alp', clearAlpha );
  ctx.fillRect( 0, 0, w, h - 20 );
  
  ctx.fillStyle = 'rgba(40, 40, 40, alp)'
    .replace( 'alp', clearAlpha );
  ctx.fillRect( 0, h - 20, w, 20 );
  
  ctx.globalCompositeOperation = 'lighter';
}

function enterGathering() {
  
  this.phase = 'gathering';
  time = 0;
  
  joinPoints = [];
  for( var i = 0; i < joinPointCount; ++i )
    joinPoints.push( new JoinPoint );
  
  particles.map( function( par ) { par.assignJoinPoint(); } );
}
function enterSettling() {
  
  ctx.lineWidth = 5;
  
  redraw();
  
  this.phase = 'settling';
  time = 0;
  
  particles.map( function( par ) { par.explode(); } );
}

function settle( render ) {
  
  updateSettling();
  if( render ) renderSettling();
}
function updateSettling() {
  particles.map( function( par ) { par.updateSettling(); } );
}
function renderSettling() {
  particles.map( function( par ) { par.renderSettling(); } );
}

function gather( render ) {
  
  updateGather();
  if( render ) renderGather();
}
function updateGather() {
  jitter2 = time / gatheringTime * jitter;
  
  ctx.lineWidth = time / gatheringTime * 10 + 3;
  
  particles.map( function( par ) { par.updateGathering(); } );
}
function renderGather() {
  particles.map( function( par ) { par.renderGathering(); } );
}

		// particle constructor //

function Particle() {
  
  this.x = Math.random() * w;
  this.y = Math.random() * -100;
  this.vx = Math.random() * 2 - 1;
  this.vy = Math.random() * -10;
  
  this.hue = this.x / w;
  
  this.last = {};
  this.joinPoint;
}
Particle.prototype.assignJoinPoint = function() {
  
  var nearest = {dist: Infinity, index: 0};
  
  for( var i = 0; i < joinPointCount; ++i ){
    
    var x = this.x - joinPoints[ i ].x,
        y = this.y - joinPoints[ i ].x,
        dist = x*x + y*y;
    
    if( dist < nearest.dist ) {
      
      nearest.dist = dist;
      nearest.index = i;
    }
  }
  
  this.joinPoint = joinPoints[ nearest.index ];
}

Particle.prototype.updateSettling = function() {
  
  this.last.x = this.x;
  this.last.y = this.y;
  
  this.x += this.vx;
  this.y += this.vy += gravity;
  this.hue -= ( this.hue - this.x/w) / hueAttenuator;
  
  // bouncing
  if( ( this.x > w && this.vx > 0 ) || 
      ( this.x < 0 && this.vx < 0 ) )
     			this.vx *= -sideBounce;
  
  if( this.y > h - 10 && this.vy > 0 )
    			this.vy *= -bottomBounce;
  
  if( topBounce && this.y < 0 && this.vy < 0)
    			this.vy *= -bottomBounce;
}
Particle.prototype.renderSettling = function() {
  
  ctx.strokeStyle = frameColorTemplate
    .replace( 'hue', ( this.hue * 360 ) | 0 );
  
  ctx.beginPath();
  ctx.moveTo( this.last.x + randJitter( 2.5 ), this.last.y + randJitter( 2.5 ) );
  ctx.lineTo( this.x + randJitter( 2.5 ), this.y + randJitter( 2.5 ) );
  ctx.stroke();
}

Particle.prototype.updateGathering = function() {
  
  this.last.x = this.x;
  this.last.y = this.y;
  
  this.x -= ( this.x - this.joinPoint.x ) / xAttenuator + randJitter2( 1 );
  this.y -= ( this.y - this.joinPoint.y ) / yAttenuator + randJitter2( 1 );
  
  this.x += this.vx *= .9;
  this.y += this.vy *= .9;
  
  
  this.hue -= ( this.hue - this.x/w) / hueAttenuator / 5;
  
}
Particle.prototype.renderGathering = function() {
  
  ctx.strokeStyle = frameColorTemplate
    .replace( 'hue', ( this.hue * 360 ) | 0 );
  
  ctx.beginPath();
  ctx.moveTo( this.last.x, this.last.y );
  ctx.lineTo( this.x, this.y );
  ctx.stroke();
}

Particle.prototype.explode = function() {
	var radient = Math.random() * Math.PI * 2,
      power = ( Math.random()/2 + .5) * explosionPower;
  this.vx = Math.cos( radient ) * power;
  this.vy = Math.sin( radient) * power;
}

		// joinPoint constructor //

function JoinPoint() {
  
  this.x = Math.random() * w;
  this.y = Math.random() * ( h / 2 );
  
}
		
		// just utility functions //

function randJitter( proportion ) {
  
  return Math.random() * jitter / proportion - jitter / 2 / proportion;
}
function randJitter2( proportion ) {
  
  return Math.random() * jitter2 / proportion - jitter2 / 2 / proportion;
}

		// and here we go! //

init();

		// resize handler //

window.addEventListener( 'resize', function() {
  
  w = c.width = window.innerWidth;
  h = c.height = window.innerHeight;
  
  redraw();
} );