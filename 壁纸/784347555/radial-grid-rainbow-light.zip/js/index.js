'use strict';

var w = c.width = window.innerWidth,
    h = c.height = window.innerHeight,
    ctx = c.getContext('2d'),
    opts = {

  lenIncrement: 3,
  startLen: 6,
  endLen: Math.sqrt(w * w / 4 + h * h / 4),
  arcJitter: .1,
  circleJitter: 6,
  subtractor: 1.8,

  sectorCount: 40,
  arcCount: 5,
  circleCount: 5,
  apply: init,

  arcTemplateColor: 'hsl(hue, 80%, 50%)',
  arcHueVariation: 30,
  tickHueMultiplier: 1,
  repaintAlpha: .02,
  shadowBlur: 1,

  cenX: w / 2,
  cenY: h / 2
},
    gui = new dat.GUI(),
    circles = [],
    tick = Math.random() * 360 | 0,
    first = true;

function init() {

  ctx.fillStyle = '#333';
  ctx.fillRect(0, 0, w, h);

  circles.length = 0;
  for (var i = 0; i < opts.circleCount; ++i) {
    circles.push(new Circle(i));
  }if (first) {

    var metrics = gui.addFolder('metrics');
    metrics.add(opts, 'lenIncrement', .1, 10);
    metrics.add(opts, 'startLen', 0, 40);
    metrics.add(opts, 'endLen', 100, opts.endLen);
    metrics.add(opts, 'arcJitter', 0, 1);
    metrics.add(opts, 'circleJitter', 0, 20);
    metrics.add(opts, 'subtractor', 0, 3);
    metrics.add(opts, 'cenX', 0, w);
    metrics.add(opts, 'cenY', 0, h);

    var counts = gui.addFolder('counts');
    counts.add(opts, 'sectorCount', 1, 100);
    counts.add(opts, 'arcCount', 1, 80);
    counts.add(opts, 'circleCount', 1, 20);
    counts.add(opts, 'apply');

    var colors = gui.addFolder('colors');
    colors.add(opts, 'arcTemplateColor');
    colors.add(opts, 'arcHueVariation', 0, 100);
    colors.add(opts, 'tickHueMultiplier', 0, 10);
    colors.add(opts, 'repaintAlpha', 0, 1);
    colors.add(opts, 'shadowBlur', 0, 8);

    first = false;

    loop();
  }
}

function loop() {

  window.requestAnimationFrame(loop);

  step();
  draw();
}
function step() {

  ++tick;

  circles.map(function (circle) {
    return circle.step();
  });
}
function draw() {

  ctx.shadowBlur = 0;
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = 'rgba(0,0,0,alp)'.replace('alp', opts.repaintAlpha);
  ctx.fillRect(0, 0, w, h);
  ctx.globalCompositeOperation = 'lighter';
  ctx.shadowBlur = opts.shadowBlur;

  circles.map(function (circle) {
    return circle.draw();
  });
}

function Circle(i) {

  this.arcs = [];

  this.reset();
  this.len = (opts.endLen - opts.startLen) * i / opts.circleCount + opts.startLen;
}
Circle.prototype.reset = function () {

  this.len = opts.startLen;

  this.arcs.length = 0;
  for (var i = 0; i < opts.arcCount; ++i) {
    this.arcs.push({
      pos: Math.random() * opts.sectorCount | 0
    });
  }
};
Circle.prototype.step = function () {

  this.len += opts.lenIncrement;
  if (this.len >= opts.endLen) this.reset();

  this.arcs.map(function (arc) {
    return arc.pos += Math.random() * 3 - opts.subtractor | 0;
  });
};
Circle.prototype.draw = function () {

  var self = this;

  this.arcs.map(function (arc) {

    var rad = arc.pos / opts.sectorCount * Math.PI * 2,
        rad2 = rad + Math.PI * 2 / opts.sectorCount;

    ctx.fillStyle = ctx.shadowColor = opts.arcTemplateColor.replace('hue', arc.pos / opts.sectorCount * 360 + opts.arcHueVariation + tick * opts.tickHueMultiplier);

    ctx.beginPath();
    ctx.arc(opts.cenX + Math.random() * opts.circleJitter, opts.cenY + Math.random() * opts.circleJitter, self.len + opts.lenIncrement, rad2 + Math.random() * opts.arcJitter, rad + Math.random() * opts.arcJitter, true);

    ctx.arc(opts.cenX + Math.random() * opts.circleJitter, opts.cenY + Math.random() * opts.circleJitter, self.len, rad + Math.random() * opts.arcJitter, rad2 + Math.random() * opts.arcJitter);

    ctx.fill();
  });
};

init();

window.addEventListener('resize', function () {

  w = c.width = window.innerWidth;
  h = c.height = window.innerHeight;

  opts.cenX = w / 2;
  opts.cenY = h / 2;
  opts.endLen = Math.sqrt(w * w / 4 + h * h / 4);

  init();
});