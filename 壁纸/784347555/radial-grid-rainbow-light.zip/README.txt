A Pen created at CodePen.io. You can find this one at http://codepen.io/towc/pen/vOxGbr.

 just another little canvas experiment for you ;)