A Pen created at CodePen.io. You can find this one at http://codepen.io/chrisgannon/pen/zrEPVV.

 May the Fork be with you.

This is using a method I've developed to create tapered strokes which is quite CPU intensive. Hopefully tapered strokes will be implemented in SVG vs. 2.0 

Mobile users might want to check out the [Dribbble GIF](https://dribbble.com/shots/2461612-Darth-Vector-SVG)