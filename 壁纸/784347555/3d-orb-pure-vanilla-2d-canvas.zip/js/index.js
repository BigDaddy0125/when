var s = c.width = c.height = 400,
		ctx = c.getContext( '2d' ),
		
		particles = [],
		rot = {
			x: 0,
			y: 0,
			z: 0,
			cos: {
				x: 1,
				y: 1,
				z: 1
			},
			sin: {
				x: 0,
				y: 0,
				z: 0
			},
			vel: {
				x: Math.random() / 80,
				y: Math.random() / 80,
				z: Math.random() / 80
			}
		},
		
		r = 100,
		d = 180,
		fl = 250,
		vp = s / 2;

function Particle(){
	var a = Math.random() * Math.PI * 2,
			b = Math.random() * Math.PI * 2,
			cosa = Math.cos( a ),
			cosb = Math.cos( b ),
			sina = Math.sin( a ),
			sinb = Math.sin( b );
	
	this.x = r * cosa * sinb;
	this.y = r * sina * sinb;
	this.z = r * cosb;
	
	this.color = 'hsla(hue,80%,50%,alp)'.replace( 'hue', ( a + b ) / Math.PI * 90 );
	this.screen = {};
}
Particle.prototype.setScreen = function(){
	
	var x = this.x,
			y = this.y,
			z = this.z;
	
	// rotations
	// around x
	var z1 = z;
	z = z * rot.cos.x - y * rot.sin.x;
	y = y * rot.cos.x + z1 * rot.sin.x;
	
	// around y
	var x1 = x;
	x = x * rot.cos.y - z * rot.sin.y;
	z = z * rot.cos.y + x1 * rot.sin.y;
	
	// around z
	var y1 = y;
	y = y * rot.cos.z - x * rot.sin.z;
	x = x * rot.cos.z + y1 * rot.sin.z;
	
	// translation
	z += d;
	
	// calculations
	var scale = fl / z;
	this.screen.scale = scale;
	this.screen.x = vp + scale * x;
	this.screen.y = vp + scale * y;
	this.screen.z = z; // indexing stuff
}
Particle.prototype.render = function(){
	
	var x = this.screen.x,
			y = this.screen.y,
			radius = this.screen.scale * 5,
			color = ctx.createRadialGradient( x, y, 0, x, y, radius );
	
	color.addColorStop( 0, this.color.replace( 'alp', 1 ) );
	color.addColorStop( 1, this.color.replace( 'alp', 0 ) );
	
	ctx.fillStyle = color;
	ctx.beginPath();
	ctx.arc( x, y, radius, 0, Math.PI * 2 );
	ctx.fill();
}

for( var i = 0; i < 300; ++i )
	particles.push( new Particle );

function anim(){
	
	window.requestAnimationFrame( anim );
	
	ctx.clearRect( 0, 0, s, s );
	
	rot.x += rot.vel.x;
	rot.y += rot.vel.y;
	rot.z += rot.vel.z;
	
	rot.cos.x = Math.cos( rot.x );
	rot.sin.x = Math.sin( rot.x );
	rot.cos.y = Math.cos( rot.y );
	rot.sin.y = Math.sin( rot.y );
	rot.cos.z = Math.cos( rot.z );
	rot.sin.z = Math.sin( rot.z );
	
	particles.map( function( particle ){ particle.setScreen(); } );
	particles.sort( function( a, b ){ b.screen.z - a.screen.z } );
	particles.map( function( particle ){ particle.render(); } );
	
}
anim();