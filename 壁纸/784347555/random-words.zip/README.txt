A Pen created at CodePen.io. You can find this one at http://codepen.io/LandonSchropp/pen/xLtif.

 The random word generators out there on the web are a little boring, so I made one that's more fun.