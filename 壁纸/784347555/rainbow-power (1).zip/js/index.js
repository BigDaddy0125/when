'use strict';

var w = c.width = window.innerWidth,
    h = c.height = window.innerHeight,
    ctx = c.getContext('2d'),
    opts = {

  count: 50,
  baseAcc: .1,
  addedAcc: .1,
  jitter: 1,
  widthMult: 1,
  cx: w / 2,
  cy: h / 2,
  tickIncrementer: 1,
  repaintAlpha: .1,
  shadowBlur: 0,
  spawnProb: 1,
  minDist: Math.min(w, h) / 4,
  maxDist: Math.sqrt(w * w / 4 + h * h / 4) // distance from center to corners
},
    particles = [],
    tick = Math.random() * 360 | 0,
    first = true,
    tau = Math.PI * 2;

function init() {

  ctx.fillStyle = '#222';
  ctx.fillRect(0, 0, w, h);

  particles.length = 0;

  if (first) {

    var gui = new dat.GUI();
    gui.add(opts, 'count', 1, 100);
    gui.add(opts, 'baseAcc', .01, 2);
    gui.add(opts, 'addedAcc', 0, 1);
    gui.add(opts, 'jitter', 0, Math.PI);
    gui.add(opts, 'widthMult', .1, 4);
    gui.add(opts, 'tickIncrementer', 0, 10);
    gui.add(opts, 'repaintAlpha', 0, 1);
    gui.add(opts, 'shadowBlur', 0, 10);
    gui.add(opts, 'minDist', 0, Math.max(w, h) / 2);
    gui.add(opts, 'maxDist', 0, Math.max(w, h));

    gui.close();

    loop();

    for (var i = 0; i < 100; ++i) {
      update();
    }first = false;
  }
}

function loop() {

  window.requestAnimationFrame(loop);

  update();
  render();
}

function update() {

  tick += opts.tickIncrementer;

  if (particles.length < opts.count && Math.random() < opts.spawnProb) particles.push(new Particle());

  particles.map(function (particle) {
    return particle.update();
  });
}
function render() {

  ctx.shadowBlur = 0;
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = 'rgba(0,0,0,alp)'.replace('alp', opts.repaintAlpha);
  ctx.fillRect(0, 0, w, h);
  ctx.globalCompositeOperation = 'lighter';
  ctx.shadowBlur = opts.shadowBlur;

  particles.map(function (particle) {
    return particle.render();
  });
}

function Particle() {

  this.reset();
}
Particle.prototype.reset = function () {

  this.rad = Math.random() * tau;
  var dist = Math.random() * (opts.maxDist - opts.minDist) + opts.minDist,
      acc = opts.baseAcc + Math.random() * opts.addedAcc,
      cos = Math.cos(this.rad),
      sin = Math.sin(this.rad);

  this.color = 'hsla( hue, 80%, 50%, alp )'.replace('hue', tick + this.rad / tau * 360);

  // this is hard to read, but bear with me
  // n stays for "new"
  this.x = this.x1 = this.x2 = this.nx1 = this.nx2 = opts.cx + cos * dist;
  this.y = this.y1 = this.y2 = this.ny1 = this.ny2 = opts.cy + sin * dist;
  this.vx = this.ax = cos * -acc;
  this.vy = this.ay = sin * -acc;

  this.vel = this.acc = acc; // width tracking, saves a lot of trigonometry

  this.rad += Math.PI / 2; // gets the perpendicular
};
Particle.prototype.update = function () {

  var x = this.x,
      y = this.y;

  this.x += this.vx += this.ax;
  this.y += this.vy += this.ay;
  this.vel += this.acc;

  var width = this.vel * opts.widthMult,
      nRad = this.rad + (2 * Math.random() - 1) * opts.jitter,
      cos = Math.cos(nRad) * width,
      sin = Math.sin(nRad) * width;

  this.x1 = this.nx1;
  this.x2 = this.nx2;
  this.y1 = this.ny1;
  this.y2 = this.ny2;

  // get it?
  this.nx1 = this.x + cos;
  this.ny1 = this.y + sin;
  this.nx2 = this.x - cos;
  this.ny2 = this.y - sin;

  if (this.x > opts.cx && x < opts.cx || this.x < opts.cx && x > opts.cx) this.reset();
};
Particle.prototype.render = function () {

  ctx.fillStyle = ctx.shadowColor = this.color.replace('alp', .75 - Math.random() * .5);
  ctx.beginPath();
  ctx.moveTo(this.x1, this.y1);
  ctx.lineTo(this.x2, this.y2);
  ctx.lineTo(this.nx2, this.ny2);
  ctx.lineTo(this.nx1, this.ny1);
  ctx.fill();
};

init();

window.addEventListener('resize', function () {

  w = c.width = window.innerWidth;
  h = c.height = window.innerHeight;

  opts.cx = w / 2;
  opts.cy = h / 2;
  opts.minDist = Math.min(w, h) / 4;
  opts.maxDist = Math.sqrt(w * w / 4 + h * h / 4);

  init();
});

c.addEventListener('click', function (e) {

  opts.cx = e.clientX;
  opts.cy = e.clientY;

  init();
});